import React from "react";

export default function Loading() {
    return <span className="k-icon k-i-loading"></span>;
}
