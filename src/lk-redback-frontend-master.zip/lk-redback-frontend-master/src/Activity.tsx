import React from "react";
import { withRouter } from "react-router-dom";

const Activity = (props) => (
  <div>In Developing</div>
);

export default withRouter(Activity);
