package coachingmateanalytics.coachingmate.config;


/**
 * @Auther: Saul
 * @Date: 1/10/20 09:50
 * @Description:
 */
public class SecurityConfig{

}

//
//@EnableWebSecurity
//public class SecurityConfig extends WebSecurityConfigurerAdapter {
//    @Override
//    protected void configure(HttpSecurity http) throws Exception {
//        http.requiresChannel()
//                .anyRequest()
//                .requiresSecure();
//    }
//}
